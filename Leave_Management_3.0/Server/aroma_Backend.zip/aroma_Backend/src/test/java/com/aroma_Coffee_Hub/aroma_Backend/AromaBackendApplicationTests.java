package com.aroma_Coffee_Hub.aroma_Backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AromaBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
