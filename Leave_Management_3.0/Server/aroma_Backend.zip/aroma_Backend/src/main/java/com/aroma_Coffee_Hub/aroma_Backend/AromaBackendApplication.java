package com.aroma_Coffee_Hub.aroma_Backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AromaBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(AromaBackendApplication.class, args);
	}

}
